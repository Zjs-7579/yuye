<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style>
#app {
  box-sizing: border-box;
  background-color: #f3f5f9;
}
* {
  padding: 0;
  margin: 0;
}
a {
  text-decoration: none;
  color: #000;
}
.el-form-item__error {
  padding-top: 0 !important;
}
</style>
