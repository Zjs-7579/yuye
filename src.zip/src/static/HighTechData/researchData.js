const researchDataList = [
  {
    id: "01",
    type: "累计发明专利申请数",
    Model: "business_income",
  },
  {
    id: "02",
    type: "累计实用新型申请数",
    Model: "main_business_income",
  },
  {
    id: "03",
    type: "累计外观设计申请数",
    Model: "high_tech_income",
  },
  {
    id: "04",
    type: "累计拥有有效发明专利授权数",
    Model: "main_income_rate",
  },
  {
    id: "05",
    type: "累计拥有有效实用新型授权数",
    Model: "total_exports",
  },
  {
    id: "06",
    type: "累计拥有有效外观设计授权数",
    Model: "high_tech_exports",
  },
  {
    id: "07",
    type: "累计发表论文数",
    Model: "nterprise_added",
  },
  {
    id: "08",
    type: "累计出版科技著作数",
    Model: "wages",
  },
  {
    id: "09",
    type: "累计拥有软件著作权数",
    Model: "depreciation",
  },
  {
    id: "10",
    type: "累计拥有IC布图版权数",
    Model: "profit",
  },
  {
    id: "11",
    type: "累计拥有注册商标数",
    Model: "main_business_profit",
  },
  {
    id: "12",
    type: "累计参编技术标准数（国际/国家/行业）",
    Model: "main_business_rate",
  },
  {
    id: "13",
    type: "累计发现植物新品种数",
    Model: "taxes_payable",
  },
  {
    id: "14",
    type: "累计获取新药（医药、农药、兽药）证书",
    Model: "income_tax",
  },
  {
    id: "15",
    type: "累计科技奖项（国家级/省级/市级）",
    Model: "personal_tax",
  },
  {
    id: "16",
    type: "累计重点实验室数量（国家级/省级/市级）",
    Model: "value_added_tax",
  },
  {
    id: "17",
    type: "累计工程中心数量（国家级/省级/市级）",
    Model: "turnover",
  },
  {
    id: "18",
    type: "累计项目数量（国家级/省级/市级）",
    Model: "other_taxes",
  },
  {
    id: "19",
    type: "累计获得国家资助经费金额（万元）",
    Model: "actual_pref_taxes",
  },
  {
    id: "20",
    type: "累计获得省级资助经费金额（万元）",
    Model: "income_tax_pref",
  },
  {
    id: "21",
    type: "累计获得市级资助经费金额（万元） ",
    Model: "value_added_pref",
  },
];

export default researchDataList;
