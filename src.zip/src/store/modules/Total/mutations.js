export default {
  UserName(state, res) {
    state.userName = res.user_name;
  },
  // UninInfo(state, res){
  //     state.userInfo.UninInfo = res
  // },

  // MODE_dataAddForm(state, res){

  //     state.dateForm.push(res)
  // }
};
