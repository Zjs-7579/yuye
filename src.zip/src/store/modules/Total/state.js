export default {
  userName: "",
  //unitInfo: [],
  //首页下载地址 操作志愿 国策
  DownAddress: "http://rent.greatbayit.com/yuye/publicrs/image/",
};
