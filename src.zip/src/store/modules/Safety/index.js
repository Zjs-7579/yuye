import state from "./state";
import mutations from "./mutations";
// import actions from "./actions"
// import getters from "./getters"
const Safety = {
  state: state,
  mutations: mutations,
};

export default Safety;
