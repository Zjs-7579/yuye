export default {
  User_UserName(state, res) {
    state.userName = res.user_name;
  },
};
