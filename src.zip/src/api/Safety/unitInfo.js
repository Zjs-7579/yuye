import http from "../httpConfig";

export async function MODE_UnitInfoData(parmse) {
  const res = await http.post("modern/ty/apply", parmse);
  console.log(res);
  return res;
}
