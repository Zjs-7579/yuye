import http from "../httpConfig";

export async function userTaskid() {
  const res = await http.get(`safety/ty/task/createTaskId`);
  return res;
}
