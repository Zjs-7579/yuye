<template>
  <div>
    <AdminRoleTable></AdminRoleTable>
  </div>
</template>

<script>
import AdminRoleTable from "./adminRoleTable.vue";
export default {
  components: { AdminRoleTable },
};
</script>

<style></style>
