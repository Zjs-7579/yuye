<template>
  <div>
    <AdminUserTable></AdminUserTable>
  </div>
</template>

<script>
import AdminUserTable from "./adminUserTable.vue";
export default {
  components: { AdminUserTable },
};
</script>

<style></style>
